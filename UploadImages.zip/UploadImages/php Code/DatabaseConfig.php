<?php

//Define your host here.
$HostName = "localhost";

//Define your database username here.
$HostUser = "id5594573_tuuhmazyn";

//Define your database password here.
$HostPass = "DBPASS";

//Define your database name here.
$DatabaseName = "id5594573_imagetesting";

?>